﻿-- SQL Manager for PostgreSQL 6.3.1.54838
-- ---------------------------------------
-- Host      : localhost
-- Database  : api
-- Version   : PostgreSQL 14.1, compiled by Visual C++ build 1914, 64-bit



SET check_function_bodies = false;
--
-- Structure for table persona (OID = 16396) : 
--
SET search_path = public, pg_catalog;
CREATE TABLE public.persona (
    id serial NOT NULL,
    fullname text,
    birth date,
    id_persona integer NOT NULL
)
WITH (oids = false);
--
-- Structure for table tipo_persona (OID = 16405) : 
--
CREATE TABLE public.tipo_persona (
    id serial NOT NULL,
    descripcion varchar(10)
)
WITH (oids = false);
--
-- Data for table public.persona (OID = 16396) (LIMIT 0,2)
--
INSERT INTO persona (id, fullname, birth, id_persona)
VALUES (1, 'Heidy Benavidez', '1990-08-25', 1);

INSERT INTO persona (id, fullname, birth, id_persona)
VALUES (10, 'Lorenssa2223', '1995-12-05', 1);

--
-- Data for table public.tipo_persona (OID = 16405) (LIMIT 0,3)
--
INSERT INTO tipo_persona (id, descripcion)
VALUES (1, 'Hijo');

INSERT INTO tipo_persona (id, descripcion)
VALUES (2, 'Madre');

INSERT INTO tipo_persona (id, descripcion)
VALUES (3, 'Padre');

--
-- Definition for index persona_idx (OID = 16420) : 
--
CREATE UNIQUE INDEX persona_idx ON public.persona USING btree (fullname, birth, id_persona);
--
-- Definition for index tipo_persona_pkey (OID = 16409) : 
--
ALTER TABLE ONLY tipo_persona
    ADD CONSTRAINT tipo_persona_pkey
    PRIMARY KEY (id);
--
-- Definition for index persona_pkey (OID = 16411) : 
--
ALTER TABLE ONLY persona
    ADD CONSTRAINT persona_pkey
    PRIMARY KEY (id);
--
-- Definition for index persona_fk (OID = 16413) : 
--
ALTER TABLE ONLY persona
    ADD CONSTRAINT persona_fk
    FOREIGN KEY (id_persona) REFERENCES tipo_persona(id);
--
-- Data for sequence public.persona_id_seq (OID = 16395)
--
SELECT pg_catalog.setval('persona_id_seq', 10, true);
--
-- Data for sequence public.tipo_persona_id_seq (OID = 16404)
--
SELECT pg_catalog.setval('tipo_persona_id_seq', 1, false);
--
-- Comments
--
COMMENT ON SCHEMA public IS 'standard public schema';

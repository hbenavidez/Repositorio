CREATE DATABASE api;

CREATE TABLE IF NOT EXISTS public.persona
(
    id integer NOT NULL DEFAULT nextval('persona_id_seq'::regclass),
    fullname text COLLATE pg_catalog."default",
    birth date,
    id_persona integer NOT NULL,
    CONSTRAINT persona_pkey PRIMARY KEY (id_persona)
);

INSERT INTO public.persona(
	id, fullname, birth, id_persona)
	VALUES (1, 'Heidy Benavidez', '1990-08-25', 1);
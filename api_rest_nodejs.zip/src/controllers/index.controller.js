
const { response } = require('express');
const {Pool} = require('pg');
//const { password } = require('pg/lib/defaults');

const pool = new Pool ({
        host:'localhost',
        user: 'postgres',
        password :'hbenavidez123',
        database : 'api'
        //port : '5432'
    });

/*const getUsers = (req,res) => {
 
    res.send('users');

}*/

const getPersonas = async (req,res) => {
 
    //res.send('personas');

    const response = await pool.query ('SELECT * from public.persona');
    console.log(response.rows);
    res.status(200).json(response.rows)    
    // res.send('personas');
}

//consultar por id una persona
const  getPersonaById = async (req,res) => {
    const id =req.params.id;
    const response = await pool.query('SELECT * from persona where id= $1',[id]);
    res.json(response.rows);
}

const CreatePersona = async(req,res) => {

    const {fullname, birth,id_persona} = req.body;
    //console.log(req.body);
    const response = await pool.query ('INSERT INTO persona (fullname,birth,id_persona) VALUES ($1,$2,$3)',[fullname,birth,id_persona]);
    console.log(response);
    res.json ({
        message :'Persona creada exitosamente',
        body:{
            persona: {fullname,birth,id_persona}
        }

    })
    //res.send('Persona creada');
};

// actualizar una persona

const UpdatePersona = async (req,res) => {

     const id =req.params.id;
     const {fullname, birth,id_persona} = req.body;
     const response= await pool.query('UPDATE persona SET fullname =$1, birth=$2,id_persona=$3 where id=$4',[
         fullname,birth,id_persona,id])
    console.log(response);
     res.json('Datos de persona actualizado');

};

//Eliminar una persona

const DeletePersona = async (req,res) =>{

    const id = req.params.id;
    const response= await pool.query('DELETE from persona where id=$1',[id]);
    console.log(response);
    res.json(`Persona con id N° ${id} fue eliminado exitosamente`);

}

module.exports ={

//getUsers
getPersonas,
getPersonaById,
CreatePersona,
UpdatePersona,
DeletePersona


}

const { Router} = require ('express');
const res = require('express/lib/response');
const router = Router();



const { getPersonas, CreatePersona,getPersonaById, DeletePersona,UpdatePersona} = require ('../controllers/index.controller')
//consulta persona
router.get('/personas',getPersonas);
//Id de la persona
router.get('/personas/:id',getPersonaById);
// crea una persona
router.post('/personas',CreatePersona);
//actualizar datos a una persona
router.put('/personas/:id',UpdatePersona);

//eliminar una persona
router.delete('/personas/:id',DeletePersona);

//const {getUsers} = require ('../controllers/index.controller')
//router.get('/users',getUsers);

module.exports = router;